const inputInfo = [
    {
        tag: 'title',
        name: 'Nombre',
        placeholder: 'Ingrese Nombre',
        type: 'text'
    },
    {
        tag: 'price',
        name: 'Precio',
        placeholder: 'Ingrese precio',
        type: 'number'
    },
    {
        tag: 'thumbnail',
        name: 'URL foto',
        placeholder: 'Ingrese URL',
        type: 'text'
    }
];

const productosKeys = [
    'Nombre',
    'Precio',
    'Foto'];